#!/bin/bash
# Run on-demand on the frontend EC2 box, right before the cert-expiry demo --
# NOT part of frontend.sh boot userdata, since this cert is 1 hour, not
# long-lived. Re-run to reissue and repeat the drill for a second showing.
#
# Usage: sudo ./cert-demo.sh [public-ip-or-hostname-for-SAN]
# If no argument is given, the box's own public IPv4 is looked up via IMDSv2.

LOGS_FOLDER="/var/log/expense"
sudo mkdir -p $LOGS_FOLDER
sudo chown -R ec2-user:ec2-user $LOGS_FOLDER
sudo chmod -R 755 $LOGS_FOLDER
LOGS_FILE="$LOGS_FOLDER/cert-demo.log"

USERID=$(id -u)
R="\e[31m"
G="\e[32m"
Y="\e[33m"
N="\e[0m"
TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")

if [ $USERID -ne 0 ]; then
    echo -e "$TIMESTAMP [ERROR] $R Please run this script with root access $N" | tee -a $LOGS_FILE
    exit 1
fi

VALIDATE(){
    if [ $1 -ne 0 ]; then
        echo -e "$TIMESTAMP [ERROR] $2 ... $R FAILURE $N" | tee -a $LOGS_FILE
        exit 1
    else
        echo -e "$TIMESTAMP [INFO] $2 ... $G SUCCESS $N" | tee -a $LOGS_FILE
    fi
}

SAN_IP="$1"
if [ -z "$SAN_IP" ]; then
    TOKEN=$(curl -sX PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")
    SAN_IP=$(curl -sH "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/public-ipv4)
fi
VALIDATE $? "Looked up public IP for SAN ($SAN_IP)"

mkdir -p /etc/nginx/tls

# openssl req -x509 -days N is integer-days only (shortest is 24h) -- there is
# no way to express "1 hour" with -days. -not_after gives an exact timestamp
# but only exists from OpenSSL 3.2 onward; earlier versions need the
# clock-shift trick (Option B) instead.
OPENSSL_VERSION=$(openssl version | awk '{print $2}')
OPENSSL_MAJOR=$(echo $OPENSSL_VERSION | cut -d. -f1)
OPENSSL_MINOR=$(echo $OPENSSL_VERSION | cut -d. -f2)

if [ "$OPENSSL_MAJOR" -gt 3 ] || { [ "$OPENSSL_MAJOR" -eq 3 ] && [ "$OPENSSL_MINOR" -ge 2 ]; }; then
    echo -e "$TIMESTAMP [INFO] OpenSSL $OPENSSL_VERSION supports -not_after ... $G Option A $N" | tee -a $LOGS_FILE
    openssl req -x509 -newkey rsa:2048 -nodes \
      -keyout /etc/nginx/tls/expense.key \
      -out    /etc/nginx/tls/expense.crt \
      -not_before "$(date -u +%y%m%d%H%M%SZ)" \
      -not_after  "$(date -u -d '+1 hour' +%y%m%d%H%M%SZ)" \
      -subj "/CN=expense.local" \
      -addext "subjectAltName=IP:$SAN_IP" &>> $LOGS_FILE
    VALIDATE $? "Issued 1-hour self-signed cert (Option A -- not_after)"
else
    echo -e "$TIMESTAMP [INFO] OpenSSL $OPENSSL_VERSION lacks -not_after ... $Y Option B (clock-shift) $N" | tee -a $LOGS_FILE
    date -s "+23 hours" &>> $LOGS_FILE
    openssl req -x509 -newkey rsa:2048 -nodes \
      -keyout /etc/nginx/tls/expense.key \
      -out    /etc/nginx/tls/expense.crt \
      -days 1 \
      -subj "/CN=expense.local" \
      -addext "subjectAltName=IP:$SAN_IP" &>> $LOGS_FILE
    CERT_STATUS=$?
    chronyc -a makestep &>> $LOGS_FILE || systemctl restart systemd-timesyncd &>> $LOGS_FILE
    VALIDATE $CERT_STATUS "Issued 1-hour self-signed cert (Option B -- clock-shift)"
fi

chmod 600 /etc/nginx/tls/expense.key
VALIDATE $? "Restricting key permissions"

cp "$(dirname "$0")/nginx-tls.conf" /etc/nginx/conf.d/expense-tls.conf
VALIDATE $? "Installing TLS server block"

nginx -t &>> $LOGS_FILE
VALIDATE $? "Validating nginx config"

systemctl reload nginx &>> $LOGS_FILE
VALIDATE $? "Reloading nginx"

echo -e "$TIMESTAMP [INFO] Cert expires at $(openssl x509 -enddate -noout -in /etc/nginx/tls/expense.crt) ... $G DONE $N" | tee -a $LOGS_FILE
