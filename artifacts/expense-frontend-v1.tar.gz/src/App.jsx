import { useEffect, useRef, useState } from 'react';
import { Wallet } from 'lucide-react';
import { api } from './api';
import CategorySection from './components/CategorySection';
import ExpenseList from './components/ExpenseList';
import StatsRow from './components/StatsRow';
import Toast from './components/Toast';
import './app.css';

export default function App() {
  const [categories, setCategories] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [toast, setToast] = useState(null);
  const toastTimer = useRef(null);

  function notify(message, type = 'success') {
    clearTimeout(toastTimer.current);
    setToast({ message, type });
    toastTimer.current = setTimeout(() => setToast(null), 3500);
  }

  async function loadAll() {
    try {
      const [cats, exps] = await Promise.all([api.getCategories(), api.getExpenses()]);
      setCategories(cats);
      setExpenses(exps);
      setLoadError('');
    } catch (err) {
      setLoadError("Couldn't reach the server");
    }
  }

  useEffect(() => {
    loadAll().finally(() => setLoading(false));
  }, []);

  async function handleRefresh() {
    await loadAll();
    notify('Refreshed.', 'success');
  }

  return (
    <div className="app">
      <header className="app__header">
        <div className="app__header-icon">
          <Wallet size={22} />
        </div>
        <div className="app__header-text">
          <h1>Expense Tracker</h1>
          <p>Track and manage your daily expenses</p>
        </div>
        <div className="app__header-badges">
          <span className="badge-chip badge-chip--tier">3-Tier</span>
          <span className="badge-chip badge-chip--aws">AWS EC2</span>
        </div>
      </header>

      <Toast toast={toast} />

      <main className="app__main">
        {loading ? (
          <p className="empty-state">Loading…</p>
        ) : loadError ? (
          <p className="form-error">{loadError}</p>
        ) : (
          <>
            <StatsRow expenses={expenses} />
            <CategorySection categories={categories} setCategories={setCategories} notify={notify} />
            <ExpenseList
              categories={categories}
              expenses={expenses}
              setExpenses={setExpenses}
              notify={notify}
              onRefresh={handleRefresh}
            />
          </>
        )}
      </main>

      <footer className="app__footer">
        Expense Tracker — 3-Tier Architecture on AWS EC2 · Frontend → Backend (Node.js) → Database (MySQL)
      </footer>
    </div>
  );
}
