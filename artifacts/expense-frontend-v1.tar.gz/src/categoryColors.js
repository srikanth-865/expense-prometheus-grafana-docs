// Categories are user-created (not a fixed enum), so badge colors are
// assigned deterministically by hashing the category id into a fixed palette
// rather than hardcoded per name.
const PALETTE = [
  { bg: '#fef3c7', fg: '#92400e' },
  { bg: '#dbeafe', fg: '#1e40af' },
  { bg: '#f3e8ff', fg: '#6b21a8' },
  { bg: '#fce7f3', fg: '#9d174d' },
  { bg: '#d1fae5', fg: '#065f46' },
  { bg: '#e0e7ff', fg: '#3730a3' },
  { bg: '#ffe4e6', fg: '#9f1239' },
  { bg: '#ecfccb', fg: '#3f6212' },
];

export function categoryColor(categoryId) {
  const idx = Math.abs(Number(categoryId) || 0) % PALETTE.length;
  return PALETTE[idx];
}
