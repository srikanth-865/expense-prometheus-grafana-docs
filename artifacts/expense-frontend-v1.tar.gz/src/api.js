// Defaults to relative paths so requests go through nginx's /api/ reverse
// proxy in production. Set VITE_API_URL to hit a backend directly (e.g. for
// local dev without nginx in front).
const API_URL = import.meta.env.VITE_API_URL || '';

class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

async function request(path, options = {}) {
  let res;
  try {
    res = await fetch(`${API_URL}${path}`, {
      headers: { 'Content-Type': 'application/json' },
      ...options,
    });
  } catch (err) {
    throw new ApiError(0, "Couldn't reach the server");
  }

  if (res.status === 204) {
    return null;
  }

  const body = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new ApiError(res.status, body.error || `Request failed (${res.status})`);
  }

  return body;
}

export const api = {
  getCategories: () => request('/api/categories'),
  createCategory: (data) =>
    request('/api/categories', { method: 'POST', body: JSON.stringify(data) }),
  deleteCategory: (id) => request(`/api/categories/${id}`, { method: 'DELETE' }),

  getExpenses: () => request('/api/expenses'),
  createExpense: (data) =>
    request('/api/expenses', { method: 'POST', body: JSON.stringify(data) }),
  updateExpense: (id, data) =>
    request(`/api/expenses/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteExpense: (id) => request(`/api/expenses/${id}`, { method: 'DELETE' }),
};

export { ApiError };
