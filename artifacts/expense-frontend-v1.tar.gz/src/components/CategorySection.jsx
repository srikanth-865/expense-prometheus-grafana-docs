import { useState } from 'react';
import { PlusCircle, Trash2, Layers } from 'lucide-react';
import { iconFor } from '../icons';
import { categoryColor } from '../categoryColors';
import IconPicker from './IconPicker';
import { api, ApiError } from '../api';

export default function CategorySection({ categories, setCategories, notify }) {
  const [name, setName] = useState('');
  const [icon, setIcon] = useState('utensils');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [deleteError, setDeleteError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('Category name is required.');
      return;
    }

    setSubmitting(true);
    try {
      const created = await api.createCategory({ name: name.trim(), icon });
      setCategories((prev) => [...prev, created]);
      setName('');
      setIcon('utensils');
      notify(`Category "${created.name}" added.`, 'success');
    } catch (err) {
      if (err instanceof ApiError && (err.status === 400 || err.status === 409)) {
        setError(err.message);
      } else {
        setError("Couldn't reach the server");
      }
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(id) {
    setDeleteError('');
    try {
      await api.deleteCategory(id);
      setCategories((prev) => prev.filter((c) => c.id !== id));
      notify('Category deleted.', 'success');
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        setDeleteError('This category has expenses and can’t be deleted.');
      } else if (err instanceof ApiError && err.status === 404) {
        setCategories((prev) => prev.filter((c) => c.id !== id));
      } else {
        setDeleteError("Couldn't reach the server");
      }
    }
  }

  return (
    <section className="section">
      <h2>
        <span className="section__icon section__icon--green">
          <Layers size={16} />
        </span>
        Categories
      </h2>

      {categories.length === 0 ? (
        <p className="empty-state">No categories yet — add one below.</p>
      ) : (
        <ul className="category-list">
          {categories.map((cat) => {
            const Icon = iconFor(cat.icon);
            const { bg, fg } = categoryColor(cat.id);
            return (
              <li
                key={cat.id}
                className="category-list__item"
                style={{ background: bg, color: fg }}
              >
                <Icon size={18} />
                <span>{cat.name}</span>
                <button
                  type="button"
                  className="icon-button icon-button--danger"
                  onClick={() => handleDelete(cat.id)}
                  aria-label={`Delete ${cat.name}`}
                >
                  <Trash2 size={16} />
                </button>
              </li>
            );
          })}
        </ul>
      )}

      {deleteError && <p className="form-error">{deleteError}</p>}

      <form onSubmit={handleSubmit} className="form form--inline">
        <input
          type="text"
          placeholder="Category name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <IconPicker value={icon} onChange={setIcon} />
        <button type="submit" disabled={submitting} className="button">
          <PlusCircle size={16} />
          Add category
        </button>
      </form>
      {error && <p className="form-error">{error}</p>}
    </section>
  );
}
