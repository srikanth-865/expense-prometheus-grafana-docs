import { BarChart3, PlusCircle, RefreshCw } from 'lucide-react';
import ExpenseForm from './ExpenseForm';
import ExpenseRow from './ExpenseRow';

export default function ExpenseList({ expenses, categories, setExpenses, notify, onRefresh }) {
  function handleCreated(expense) {
    setExpenses((prev) =>
      [expense, ...prev].sort((a, b) => (a.expense_date < b.expense_date ? 1 : -1))
    );
    notify(`Expense of ₹${Number(expense.amount).toLocaleString('en-IN')} added.`, 'success');
  }

  function handleUpdated(expense) {
    setExpenses((prev) => prev.map((e) => (e.id === expense.id ? expense : e)));
    notify('Expense updated.', 'success');
  }

  function handleDeleted(id) {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
    notify('Expense deleted.', 'success');
  }

  return (
    <>
      <section className="section">
        <h2>
          <span className="section__icon section__icon--red">
            <PlusCircle size={16} />
          </span>
          Add Expense
        </h2>
        <ExpenseForm categories={categories} onCreated={handleCreated} />
      </section>

      <section className="section">
        <div className="section__header-row">
          <h2>
            <span className="section__icon section__icon--blue">
              <BarChart3 size={16} />
            </span>
            All Expenses
          </h2>
          {onRefresh && (
            <button type="button" className="button button--outline" onClick={onRefresh}>
              <RefreshCw size={14} />
              Refresh
            </button>
          )}
        </div>

        {expenses.length === 0 ? (
          <p className="empty-state">No expenses recorded yet.</p>
        ) : (
          <div className="table-wrap">
            <table className="expense-table">
              <thead>
                <tr>
                  <th>Category</th>
                  <th>Date</th>
                  <th>Amount</th>
                  <th>Notes</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {expenses.map((expense) => (
                  <ExpenseRow
                    key={expense.id}
                    expense={expense}
                    categories={categories}
                    onUpdated={handleUpdated}
                    onDeleted={handleDeleted}
                  />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </>
  );
}
