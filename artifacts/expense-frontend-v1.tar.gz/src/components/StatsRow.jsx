import { Wallet, Receipt, Tags } from 'lucide-react';

export default function StatsRow({ expenses }) {
  const total = expenses.reduce((sum, e) => sum + Number(e.amount), 0);
  const count = expenses.length;

  let topCategory = '—';
  if (count > 0) {
    const freq = {};
    expenses.forEach((e) => {
      freq[e.category_name] = (freq[e.category_name] || 0) + 1;
    });
    topCategory = Object.keys(freq).reduce((best, cat) =>
      freq[cat] > freq[best] ? cat : best
    );
  }

  const totalLabel = `₹${total.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;

  return (
    <div className="stats-row">
      <div className="stat-card stat-card--total">
        <Wallet size={22} className="stat-card__icon" />
        <div className="stat-card__label">Total Spent</div>
        <div className="stat-card__value">{totalLabel}</div>
      </div>
      <div className="stat-card stat-card--count">
        <Receipt size={22} className="stat-card__icon" />
        <div className="stat-card__label">Expenses</div>
        <div className="stat-card__value">{count}</div>
      </div>
      <div className="stat-card stat-card--top">
        <Tags size={22} className="stat-card__icon" />
        <div className="stat-card__label">Top Category</div>
        <div className="stat-card__value">{topCategory}</div>
      </div>
    </div>
  );
}
