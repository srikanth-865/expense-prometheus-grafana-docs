import { CheckCircle2, XCircle } from 'lucide-react';

export default function Toast({ toast }) {
  if (!toast) return null;
  const Icon = toast.type === 'success' ? CheckCircle2 : XCircle;
  return (
    <div className={`toast toast--${toast.type}`}>
      <Icon size={18} />
      <span>{toast.message}</span>
    </div>
  );
}
