import { useState } from 'react';
import { Pencil, Trash2, Check, X } from 'lucide-react';
import { iconFor } from '../icons';
import { categoryColor } from '../categoryColors';
import { api, ApiError } from '../api';

function formatCurrency(amount) {
  return `₹${Number(amount).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export default function ExpenseRow({ expense, categories, onUpdated, onDeleted }) {
  const [editing, setEditing] = useState(false);
  const [categoryId, setCategoryId] = useState(expense.category_id);
  const [date, setDate] = useState(expense.expense_date.slice(0, 10));
  const [amount, setAmount] = useState(String(expense.amount));
  const [notes, setNotes] = useState(expense.notes || '');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const Icon = iconFor(expense.category_icon);
  const { bg, fg } = categoryColor(expense.category_id);

  function cancelEdit() {
    setEditing(false);
    setError('');
    setCategoryId(expense.category_id);
    setDate(expense.expense_date.slice(0, 10));
    setAmount(String(expense.amount));
    setNotes(expense.notes || '');
  }

  async function saveEdit() {
    setError('');
    const amountNum = Number(amount);
    if (amount === '' || Number.isNaN(amountNum) || amountNum <= 0) {
      setError('Amount must be a number greater than 0.');
      return;
    }
    if (!date) {
      setError('Please select a date.');
      return;
    }

    setBusy(true);
    try {
      const updated = await api.updateExpense(expense.id, {
        category_id: Number(categoryId),
        amount: amountNum,
        expense_date: date,
        notes: notes || undefined,
      });
      onUpdated(updated);
      setEditing(false);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Couldn't reach the server");
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete() {
    if (!window.confirm('Delete this expense?')) return;
    setBusy(true);
    try {
      await api.deleteExpense(expense.id);
      onDeleted(expense.id);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Couldn't reach the server");
      setBusy(false);
    }
  }

  if (editing) {
    return (
      <tr>
        <td colSpan={5}>
          <div className="form form--inline">
            <select value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.name}
                </option>
              ))}
            </select>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            <input
              type="number"
              min="0.01"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <input
              type="text"
              maxLength={500}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
            <button type="button" className="icon-button" onClick={saveEdit} disabled={busy} aria-label="Save">
              <Check size={16} />
            </button>
            <button type="button" className="icon-button" onClick={cancelEdit} disabled={busy} aria-label="Cancel">
              <X size={16} />
            </button>
          </div>
          {error && <p className="form-error">{error}</p>}
        </td>
      </tr>
    );
  }

  return (
    <tr>
      <td>
        <span className="category-badge" style={{ background: bg, color: fg }}>
          <Icon size={14} />
          {expense.category_name}
        </span>
      </td>
      <td>{expense.expense_date.slice(0, 10)}</td>
      <td className="amount-cell">{formatCurrency(expense.amount)}</td>
      <td>{expense.notes}</td>
      <td>
        <button type="button" className="icon-button" onClick={() => setEditing(true)} aria-label="Edit">
          <Pencil size={16} />
        </button>
        <button
          type="button"
          className="icon-button icon-button--danger"
          onClick={handleDelete}
          disabled={busy}
          aria-label="Delete"
        >
          <Trash2 size={16} />
        </button>
        {error && <p className="form-error">{error}</p>}
      </td>
    </tr>
  );
}
