import { ICON_CHOICES, iconFor } from '../icons';

export default function IconPicker({ value, onChange }) {
  return (
    <div className="icon-picker">
      {ICON_CHOICES.map((name) => {
        const Icon = iconFor(name);
        const selected = value === name;
        return (
          <button
            key={name}
            type="button"
            className={`icon-picker__item${selected ? ' icon-picker__item--selected' : ''}`}
            onClick={() => onChange(name)}
            aria-pressed={selected}
            title={name}
          >
            <Icon size={20} />
          </button>
        );
      })}
    </div>
  );
}
