import { useState } from 'react';
import { PlusCircle } from 'lucide-react';
import { api, ApiError } from '../api';

function today() {
  return new Date().toISOString().slice(0, 10);
}

export default function ExpenseForm({ categories, onCreated }) {
  const [categoryId, setCategoryId] = useState('');
  const [date, setDate] = useState(today());
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');

    if (!categoryId) {
      setError('Please select a category.');
      return;
    }
    const amountNum = Number(amount);
    if (amount === '' || Number.isNaN(amountNum) || amountNum <= 0) {
      setError('Amount must be a number greater than 0.');
      return;
    }
    if (!date) {
      setError('Please select a date.');
      return;
    }
    if (notes.length > 500) {
      setError('Notes must be 500 characters or fewer.');
      return;
    }

    setSubmitting(true);
    try {
      const created = await api.createExpense({
        category_id: Number(categoryId),
        amount: amountNum,
        expense_date: date,
        notes: notes || undefined,
      });
      onCreated(created);
      setAmount('');
      setNotes('');
      setDate(today());
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message);
      } else {
        setError("Couldn't reach the server");
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="form">
      <div className="form__row">
        <label>
          Category
          <select value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
            <option value="">Select a category</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>
                {cat.name}
              </option>
            ))}
          </select>
        </label>

        <label>
          Date
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </label>

        <label>
          Amount
          <input
            type="number"
            min="0.01"
            step="0.01"
            placeholder="0.00"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </label>
      </div>

      <label>
        Notes
        <input
          type="text"
          maxLength={500}
          placeholder="Optional"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
      </label>

      <button type="submit" disabled={submitting} className="button">
        <PlusCircle size={16} />
        Add expense
      </button>
      {error && <p className="form-error">{error}</p>}
    </form>
  );
}
