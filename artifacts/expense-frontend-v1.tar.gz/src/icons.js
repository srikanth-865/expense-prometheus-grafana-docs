import {
  Utensils,
  Car,
  Home,
  ShoppingBag,
  Zap,
  Coffee,
  Plane,
  Heart,
  Gift,
  Book,
  Briefcase,
  Gamepad2,
  Wifi,
  Film,
  Dumbbell,
  Wallet,
  Tag,
} from 'lucide-react';

// The curated set offered in the "Add category" icon picker.
export const ICON_CHOICES = [
  'utensils',
  'car',
  'home',
  'shopping-bag',
  'zap',
  'coffee',
  'plane',
  'heart',
  'gift',
  'book',
  'briefcase',
  'gamepad',
  'wifi',
  'film',
  'dumbbell',
  'wallet',
];

const ICON_MAP = {
  utensils: Utensils,
  car: Car,
  home: Home,
  'shopping-bag': ShoppingBag,
  zap: Zap,
  coffee: Coffee,
  plane: Plane,
  heart: Heart,
  gift: Gift,
  book: Book,
  briefcase: Briefcase,
  gamepad: Gamepad2,
  wifi: Wifi,
  film: Film,
  dumbbell: Dumbbell,
  wallet: Wallet,
};

export function iconFor(name) {
  return ICON_MAP[name] || Tag;
}
