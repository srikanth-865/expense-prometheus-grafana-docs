# expense-frontend-v1

Spec 3 of 3 — React (Vite) frontend for the 3-tier Expense Tracker.
Manages categories (with icons) and expenses against the `expense-backend-v1` API.

## Run (dev)

```bash
npm install
npm run dev            # serves on :5173, hot reload
```

By default the app calls relative `/api/...` paths, which only resolves in
production behind the nginx reverse proxy (see below). For local dev without
nginx in front, point straight at a reachable backend:

```bash
cp .env.example .env    # uncomment VITE_API_URL and set it to your backend
```

## Build & deploy to nginx (EC2)

The intended production path: `vite build` produces static files, nginx
serves them and reverse-proxies `/api/` to the backend **privately** — the
browser never talks to the backend directly, so the backend's security group
never needs to open anything but SSH + the frontend's own SG.

```bash
npm install
npm run build                       # outputs dist/

# on the frontend EC2:
sudo dnf install nginx -y
sudo rm -rf /usr/share/nginx/html/*
sudo cp -r dist/* /usr/share/nginx/html/
sudo cp nginx.conf /etc/nginx/default.d/expense.conf   # edit the proxy_pass target if needed
sudo nginx -t
sudo systemctl enable --now nginx
# after any later change to dist/ or nginx.conf:
sudo systemctl reload nginx
```

`nginx.conf`'s `proxy_pass` already points at `http://backend.daws86s.fun:8080/api/`
(the backend's private-IP DNS record from `expense-infra`) — update it only if
your backend's address changes and Route 53 hasn't caught up yet.

**Verify:**
```bash
curl http://localhost/                    # the app's index.html
curl http://localhost/api/categories       # proxied through to the backend
```

Then browse to `http://daws86s.fun` (or the frontend's public IP) — port 80
needs to be open on the frontend's security group for direct browsers (see
`browser_cidr` in `expense-infra/variables.tf`).

## Structure
```
src/
  api.js                # all fetch calls; relative /api/... by default, VITE_API_URL to override
  icons.js              # curated lucide icon set + name→component map
  categoryColors.js      # deterministic badge color per category id
  components/
    CategorySection.jsx
    IconPicker.jsx
    ExpenseForm.jsx
    ExpenseList.jsx
    ExpenseRow.jsx       # display + inline edit
    StatsRow.jsx         # total spent / expense count / top category
    Toast.jsx            # success/failure notifications
  App.jsx
  main.jsx
  app.css
nginx.conf              # deploy to /etc/nginx/default.d/expense.conf
```

## Behavior
- Categories and expenses load on startup; loading and empty states are shown.
- A stats row (total spent, expense count, top category) recomputes live from the loaded data.
- Creating/editing/deleting updates React state directly and shows a toast — no page reload.
- Amount input blocks zero, negative, empty, and non-numeric values before submit.
- A 409 on category delete (category still has expenses) shows a friendly inline message
  instead of a raw error; network failures show "Couldn't reach the server".
- Every category and expense row displays its lucide icon, plus a color-coded badge.
