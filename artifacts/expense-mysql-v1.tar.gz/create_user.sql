-- App DB user for the backend tier, per backend spec's DB_USER/DB_PASSWORD/DB_NAME.
-- Run as root/admin. Replace the password before using outside local dev.
CREATE USER IF NOT EXISTS 'expense_app'@'%' IDENTIFIED BY 'ChangeMe123!';
GRANT SELECT, INSERT, UPDATE, DELETE ON expense_db.* TO 'expense_app'@'%';
FLUSH PRIVILEGES;
