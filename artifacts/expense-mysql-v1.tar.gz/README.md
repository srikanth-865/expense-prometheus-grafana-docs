# expense-mysql-v1

Spec 1 of 3 — MySQL tier (data tier) for the 3-tier Expense Tracker.
Requires MySQL 8.0.16+ (for enforced `CHECK` constraints).

## Schema

Two tables in `expense_db`:

- **categories** — `id, name (unique), icon, created_at`
- **expenses** — `id, category_id (FK -> categories.id, ON DELETE RESTRICT), amount (> 0), expense_date, notes, created_at, updated_at`

`ON DELETE RESTRICT` on `expenses.category_id` is intentional: deleting a category that still
has expenses must fail at the database layer so the backend can surface a clean `409`
instead of a `500`. `amount > 0` is enforced by a `CHECK` constraint as defense-in-depth
alongside the backend and frontend validation (same rule, three layers).

## Files

- `schema.sql` — creates the `expense_db` database and both tables.
- `create_user.sql` — creates the `expense_app` app user with least-privilege grants (no DDL).
- `seed.sql` — a few sample categories/expenses for local dev. Idempotent (safe to re-run).

## Setup

```bash
mysql -u root -p < schema.sql
mysql -u root -p < create_user.sql
mysql -u root -p < seed.sql   # optional, for local/dev only
```

Then edit `create_user.sql`'s password before running against anything beyond local dev,
and point the backend's `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME` at this instance.

## Verify

```bash
mysql -u expense_app -p expense_db -e "SHOW TABLES;"
mysql -u root -p expense_db -e "SELECT * FROM categories;"
```

Confirm the FK guard works:

```sql
-- should fail with an FK constraint error if the category has expenses
DELETE FROM categories WHERE id = 1;
```
