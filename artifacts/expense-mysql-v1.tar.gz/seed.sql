-- Sample data for local/dev use. Safe to re-run: skips rows that already exist.
USE expense_db;

INSERT INTO categories (name, icon)
SELECT * FROM (SELECT 'Food' AS name, 'utensils' AS icon) AS tmp
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Food');

INSERT INTO categories (name, icon)
SELECT * FROM (SELECT 'Transport' AS name, 'car' AS icon) AS tmp
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Transport');

INSERT INTO categories (name, icon)
SELECT * FROM (SELECT 'Housing' AS name, 'home' AS icon) AS tmp
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Housing');

INSERT INTO categories (name, icon)
SELECT * FROM (SELECT 'Shopping' AS name, 'shopping-bag' AS icon) AS tmp
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Shopping');

INSERT INTO categories (name, icon)
SELECT * FROM (SELECT 'Utilities' AS name, 'zap' AS icon) AS tmp
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Utilities');

INSERT INTO expenses (category_id, amount, expense_date, notes)
SELECT c.id, 250.00, CURDATE(), 'Sample lunch'
FROM categories c WHERE c.name = 'Food'
AND NOT EXISTS (SELECT 1 FROM expenses WHERE notes = 'Sample lunch');

INSERT INTO expenses (category_id, amount, expense_date, notes)
SELECT c.id, 899.00, CURDATE() - INTERVAL 2 DAY, 'Cab to airport'
FROM categories c WHERE c.name = 'Transport'
AND NOT EXISTS (SELECT 1 FROM expenses WHERE notes = 'Cab to airport');
